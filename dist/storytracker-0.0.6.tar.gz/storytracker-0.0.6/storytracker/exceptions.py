#!/usr/bin/env python


class ArchiveFileNameError(ValueError):
    pass
